package lib;
import jakarta.persistence.*;
import java.util.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

/** Tracks how many physical copies of each book exist and how many are on the shelf. */
@SpringBootApplication @EnableJpaRepositories(considerNestedRepositories = true)
@RestController @RequestMapping("/inventory")
public class InventoryApp {
  @Entity @Table(name = "copies")
  public static class Copies { @Id public Long bookId; public int total, available; public Copies() {} Copies(Long id, int t) { bookId=id; total=t; available=t; } }
  public interface Repo extends JpaRepository<Copies, Long> {}

  private final Repo repo; private final JdbcTemplate jdbc;
  InventoryApp(Repo r, JdbcTemplate j) { repo = r; jdbc = j; }

  @GetMapping public List<Copies> all() { return repo.findAll(); }
  @GetMapping("/{id}") public ResponseEntity<Copies> get(@PathVariable Long id) { return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }

  // One atomic SQL statement: it only succeeds if a copy is on the shelf, so the last copy can never be lent twice.
  @PostMapping("/{id}/checkout") public ResponseEntity<Map<String,Object>> checkout(@PathVariable Long id) {
    int rows = jdbc.update("UPDATE copies SET available = available - 1 WHERE book_id = ? AND available > 0", id);
    return rows == 1 ? ResponseEntity.ok(Map.of("ok", true)) : ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("ok", false, "error", "No copies available"));
  }
  @PostMapping("/{id}/checkin") public Map<String,Object> checkin(@PathVariable Long id) {
    return Map.of("ok", jdbc.update("UPDATE copies SET available = available + 1 WHERE book_id = ? AND available < total", id) == 1);
  }

  @Bean CommandLineRunner seed() { return a -> { if (repo.count() == 0) for (long i = 1; i <= 12; i++) repo.save(new Copies(i, i == 1 ? 1 : 3)); }; }
  public static void main(String[] a) { TimeZone.setDefault(TimeZone.getTimeZone("UTC")); SpringApplication.run(InventoryApp.class, a); }
}
