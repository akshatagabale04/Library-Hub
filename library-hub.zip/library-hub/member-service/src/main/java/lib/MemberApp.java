package lib;
import jakarta.persistence.*;
import java.time.Instant;
import java.util.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

/** Library membership. Demo-level: members are identified by email only (no password). */
@SpringBootApplication @EnableJpaRepositories(considerNestedRepositories = true)
@RestController @RequestMapping("/members")
public class MemberApp {
  @Entity @Table(name = "members")
  public static class Member {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(unique = true, nullable = false) public String email;
    public String name, status = "ACTIVE"; public Instant joinedAt = Instant.now();
  }
  public interface Repo extends JpaRepository<Member, Long> { Optional<Member> findByEmailIgnoreCase(String email); }
  public record Req(String name, String email) {}
  private final Repo repo;
  MemberApp(Repo r) { repo = r; }

  @PostMapping public ResponseEntity<Object> join(@RequestBody Req r) {
    if (r.name() == null || r.name().isBlank() || r.email() == null || !r.email().contains("@"))
      return ResponseEntity.badRequest().body(Map.of("error", "A name and a valid email are required"));
    String email = r.email().trim().toLowerCase();
    if (repo.findByEmailIgnoreCase(email).isPresent()) return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "This email is already a member. Use Sign in."));
    Member m = new Member(); m.email = email; m.name = r.name().trim(); repo.save(m);
    return ResponseEntity.status(HttpStatus.CREATED).body(m);
  }
  @GetMapping public ResponseEntity<Object> byEmail(@RequestParam String email) {
    return repo.findByEmailIgnoreCase(email.trim()).<ResponseEntity<Object>>map(ResponseEntity::ok)
      .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "No member with that email")));
  }
  public static void main(String[] a) { TimeZone.setDefault(TimeZone.getTimeZone("UTC")); SpringApplication.run(MemberApp.class, a); }
}
