package lib;
import jakarta.persistence.*;
import java.util.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@SpringBootApplication @EnableJpaRepositories(considerNestedRepositories = true)
@RestController @RequestMapping("/books")
public class CatalogApp {
  @Entity @Table(name = "books")
  public static class Book {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    public String title, author, isbn, category;
    @Column(length = 1000) public String description;
    public Book() {}
    Book(String t, String a, String i, String c, String d) { title=t; author=a; isbn=i; category=c; description=d; }
  }
  public interface Repo extends JpaRepository<Book, Long> {
    List<Book> findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCase(String t, String a);
  }
  private final Repo repo;
  CatalogApp(Repo repo) { this.repo = repo; }

  @GetMapping public List<Book> list(@RequestParam(required = false) String category, @RequestParam(required = false) String q) {
    List<Book> r = (q == null || q.isBlank()) ? repo.findAll() : repo.findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCase(q.trim(), q.trim());
    if (category != null && !category.isBlank() && !category.equalsIgnoreCase("all"))
      r = r.stream().filter(b -> category.equalsIgnoreCase(b.category)).toList();
    return r.stream().sorted(Comparator.comparing((Book b) -> b.id)).toList();
  }
  @GetMapping("/{id}") public ResponseEntity<Book> get(@PathVariable Long id) {
    return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }

  @Bean CommandLineRunner seed() { return a -> { if (repo.count() > 0) return;
    repo.saveAll(List.of(
      new Book("Pride and Prejudice", "Jane Austen", "9780141439518", "fiction", "A sharp-witted comedy of manners about love, class and first impressions."),
      new Book("1984", "George Orwell", "9780451524935", "fiction", "A chilling vision of surveillance and control in a totalitarian state."),
      new Book("The Hobbit", "J.R.R. Tolkien", "9780547928227", "fantasy", "A reluctant hobbit joins a band of dwarves on a quest to reclaim a treasure."),
      new Book("Dune", "Frank Herbert", "9780441172719", "science fiction", "Politics, ecology and prophecy collide on a desert planet."),
      new Book("Sapiens", "Yuval Noah Harari", "9780062316097", "history", "A sweeping history of how humans came to dominate the planet."),
      new Book("A Brief History of Time", "Stephen Hawking", "9780553380163", "science", "An accessible tour of black holes, the Big Bang and the nature of time."),
      new Book("The Alchemist", "Paulo Coelho", "9780062315007", "fiction", "A shepherd travels in search of treasure and finds a bigger lesson."),
      new Book("Clean Code", "Robert C. Martin", "9780132350884", "technology", "Practical advice for writing code that other people can read and change."),
      new Book("Atomic Habits", "James Clear", "9780735211292", "self-help", "How tiny daily changes compound into remarkable results."),
      new Book("The Diary of a Young Girl", "Anne Frank", "9780553296983", "biography", "A teenager's diary written while hiding during the Second World War."),
      new Book("Wings of Fire", "A.P.J. Abdul Kalam", "9788173711466", "biography", "The autobiography of India's missile scientist and former president."),
      new Book("Train to Pakistan", "Khushwant Singh", "9780143065883", "history", "A novel about a village on the border during the 1947 Partition."))); }; }
  public static void main(String[] a) { TimeZone.setDefault(TimeZone.getTimeZone("UTC")); SpringApplication.run(CatalogApp.class, a); }
}
