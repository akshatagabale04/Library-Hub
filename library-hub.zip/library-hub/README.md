# Library Hub

A library website built with the same architecture as the Stride Shop e-commerce project:
React frontend -> API gateway -> Spring Boot microservices -> PostgreSQL (one database per service) + RabbitMQ.

| Service | Port | Database | Job |
|---|---|---|---|
| frontend (React) | 3000 | - | Catalogue, search, borrow, my loans, join / sign in |
| gateway | 8080 | - | Single entry: `/api/books`, `/api/loans`, `/api/members`, `/api/inventory` |
| catalog-service | 8081 | catalog_db | Books (12 seeded), search by title/author, filter by category |
| loan-service | 8082 | loan_db | Borrow / return, limits, due dates, fines; publishes events |
| member-service | 8083 | member_db | Join and look up members (email only, demo) |
| inventory-service | 8084 | inventory_db | Copies per book; atomic checkout so the last copy is never lent twice |
| notification-service | 8085 | - | Reads `loan.created` / `loan.returned` and "emails" (logged) |

Rules: 14-day loans, max 3 active loans per member, one copy of a title per member, fine 5 rupees per late day.

## Run (easiest: everything in Docker)
    docker compose up --build -d
    docker compose ps -a              # wait until all services are Up (about a minute)
Open http://localhost:3000  (RabbitMQ UI: http://localhost:15672, login guest / guest)
Watch the emails:  `docker compose logs -f notification-service`
Stop: `docker compose down` (add `-v` to wipe data)

## Try it
1. Join with any name and email, go to Catalogue, borrow a book.
2. Pride and Prejudice has only 1 copy. Borrow it, then join with a second email and try again: you get "No copies available".
3. Borrow 3 books, then a 4th: limit message.
4. My loans -> "Return 5 days late" shows the fine (5 days x 5 rupees = 25 rupees).

## Develop from your PC (Maven + Node)
    docker compose up postgres rabbitmq -d       # Postgres is published on 5433
    mvn -pl catalog-service spring-boot:run      # also: inventory-service, member-service, notification-service
    mvn -pl loan-service spring-boot:run         # after catalog, member, inventory
    mvn -pl gateway spring-boot:run
    cd frontend && npm install && npm run dev    # http://localhost:3000
Services default to `localhost:5433` (user/password `library`). Each service sets its own time zone to UTC, so the
`Asia/Calcutta` PostgreSQL error does not occur.

## Not included yet
Passwords / JWT at the gateway, reservations and waiting lists, librarian/admin screens, real email provider, tests.
