package lib;
import jakarta.persistence.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.*;

/** Orchestrates borrowing and returning: member check, limits, stock, loan record, then an async event. */
@SpringBootApplication @EnableJpaRepositories(considerNestedRepositories = true)
@RestController @RequestMapping("/loans")
public class LoanApp {
  static final int MAX_ACTIVE = 3, LOAN_DAYS = 14; static final long FINE_PER_DAY_PAISE = 500;
  @Entity @Table(name = "loans")
  public static class Loan {
    @Id public UUID id = UUID.randomUUID();
    public String memberEmail, title, status = "BORROWED"; public Long bookId;
    public Instant borrowedAt = Instant.now(); public LocalDate dueDate; public Instant returnedAt; public long finePaise;
  }
  public interface Repo extends JpaRepository<Loan, UUID> {
    List<Loan> findByMemberEmailOrderByBorrowedAtDesc(String email);
    long countByMemberEmailAndStatus(String email, String status);
    boolean existsByMemberEmailAndBookIdAndStatus(String email, Long bookId, String status);
  }
  public record Req(String email, Long bookId) {}
  record Book(Long id, String title) {}

  private final Repo repo; private final RabbitTemplate mq; private final RestClient http = RestClient.create();
  @Value("${member.url}") String member; @Value("${catalog.url}") String catalog; @Value("${inventory.url}") String inventory;
  LoanApp(Repo r, RabbitTemplate mq) { repo = r; this.mq = mq; }
  @Bean MessageConverter json() { return new Jackson2JsonMessageConverter(); }
  @Bean TopicExchange library() { return new TopicExchange("library"); }

  private static ResponseEntity<Object> err(int code, String msg) { return ResponseEntity.status(code).body(Map.of("error", msg)); }

  @PostMapping public ResponseEntity<Object> borrow(@RequestBody Req r) {
    if (r.email() == null || r.bookId() == null) return err(400, "email and bookId are required");
    String email = r.email().trim().toLowerCase();
    try { http.get().uri(member + "/members?email={e}", email).retrieve().toBodilessEntity(); }                       // 1. is a member?
    catch (RestClientResponseException e) { return err(404, "Not a library member. Please join first."); }
    if (repo.countByMemberEmailAndStatus(email, "BORROWED") >= MAX_ACTIVE) return err(409, "Borrowing limit reached (" + MAX_ACTIVE + " books). Return one first.");   // 2. limit
    if (repo.existsByMemberEmailAndBookIdAndStatus(email, r.bookId(), "BORROWED")) return err(409, "You already have this book.");
    Book b;
    try { b = http.get().uri(catalog + "/books/" + r.bookId()).retrieve().body(Book.class); }                         // 3. book exists?
    catch (RestClientResponseException e) { return err(404, "Book not found."); }
    try { http.post().uri(inventory + "/inventory/" + r.bookId() + "/checkout").retrieve().toBodilessEntity(); }      // 4. take a copy atomically
    catch (RestClientResponseException e) { return err(409, "No copies available right now."); }
    Loan l = new Loan(); l.memberEmail = email; l.bookId = b.id(); l.title = b.title(); l.dueDate = LocalDate.now().plusDays(LOAN_DAYS);
    repo.save(l);                                                                                                        // 5. record the loan
    mq.convertAndSend("library", "loan.created", Map.of("event", "created", "email", email, "title", l.title, "dueDate", l.dueDate.toString())); // 6. async event
    return ResponseEntity.status(HttpStatus.CREATED).body(l);
  }

  /** demoDaysLate lets you try the fine calculation without waiting two weeks. */
  @PostMapping("/{id}/return") public ResponseEntity<Object> giveBack(@PathVariable UUID id, @RequestParam(defaultValue = "0") int demoDaysLate) {
    Loan l = repo.findById(id).orElse(null);
    if (l == null) return err(404, "Loan not found.");
    if ("RETURNED".equals(l.status)) return err(409, "Already returned.");
    try { http.post().uri(inventory + "/inventory/" + l.bookId + "/checkin").retrieve().toBodilessEntity(); }
    catch (RestClientException e) { return err(502, "Could not update stock. Try again."); }
    long late = Math.max(0, ChronoUnit.DAYS.between(l.dueDate, LocalDate.now())) + Math.max(0, demoDaysLate);
    l.finePaise = late * FINE_PER_DAY_PAISE; l.status = "RETURNED"; l.returnedAt = Instant.now(); repo.save(l);
    mq.convertAndSend("library", "loan.returned", Map.of("event", "returned", "email", l.memberEmail, "title", l.title, "finePaise", l.finePaise));
    return ResponseEntity.ok(l);
  }
  @GetMapping public List<Loan> mine(@RequestParam String email) { return repo.findByMemberEmailOrderByBorrowedAtDesc(email.trim().toLowerCase()); }
  public static void main(String[] a) { TimeZone.setDefault(TimeZone.getTimeZone("UTC")); SpringApplication.run(LoanApp.class, a); }
}
