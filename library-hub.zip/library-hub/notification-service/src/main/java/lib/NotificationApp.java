package lib;
import java.util.Map;
import org.slf4j.*;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.converter.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/** Reacts to loan events from the bus and "sends" the email (written to the log; plug in a mail provider for real mail). */
@SpringBootApplication
public class NotificationApp {
  static final Logger log = LoggerFactory.getLogger(NotificationApp.class);
  @Bean MessageConverter json() { return new Jackson2JsonMessageConverter(); }
  @Bean TopicExchange library() { return new TopicExchange("library"); }
  @Bean Queue loansQueue() { return new Queue("notifications.loans", true); }
  @Bean Binding binding(Queue loansQueue, TopicExchange library) { return BindingBuilder.bind(loansQueue).to(library).with("loan.*"); }

  @RabbitListener(queues = "notifications.loans")
  public void onLoanEvent(Map<String, Object> e) {
    if ("created".equals(e.get("event")))
      log.info("EMAIL to {}: you borrowed \"{}\". Please return it by {}.", e.get("email"), e.get("title"), e.get("dueDate"));
    else {
      long fine = ((Number) e.get("finePaise")).longValue();
      log.info("EMAIL to {}: thanks for returning \"{}\". {}", e.get("email"), e.get("title"),
        fine > 0 ? String.format("Late fine: Rs %d.%02d", fine / 100, fine % 100) : "No fine due.");
    }
  }
  public static void main(String[] a) { SpringApplication.run(NotificationApp.class, a); }
}
