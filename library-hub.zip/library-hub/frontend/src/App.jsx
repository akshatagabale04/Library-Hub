import { useCallback, useEffect, useState } from "react";
import { API } from "./config.js";

const CATS = ["all", "fiction", "fantasy", "science fiction", "science", "history", "biography", "technology", "self-help"];
const rupees = (paise) => "₹" + (paise / 100).toFixed(2);
const load = () => { try { return JSON.parse(localStorage.getItem("member")); } catch { return null; } };
async function call(path, opts) {
  const res = await fetch(`${API}${path}`, { headers: { "Content-Type": "application/json" }, ...opts });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}

export default function App() {
  const [tab, setTab] = useState("books");
  const [books, setBooks] = useState([]);
  const [copies, setCopies] = useState({});
  const [category, setCategory] = useState("all");
  const [q, setQ] = useState("");
  const [member, setMember] = useState(load);
  const [loans, setLoans] = useState([]);
  const [msg, setMsg] = useState(null);                  // { kind: "ok" | "err", text }
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const flash = (kind, text) => setMsg({ kind, text });

  const loadStock = useCallback(async () => {
    try { const r = await call("/api/inventory"); if (r.ok) setCopies(Object.fromEntries(r.data.map((c) => [c.bookId, c]))); } catch {}
  }, []);
  const loadLoans = useCallback(async () => {
    if (!member) return setLoans([]);
    try { const r = await call(`/api/loans?email=${encodeURIComponent(member.email)}`); if (r.ok) setLoans(r.data); } catch {}
  }, [member]);

  useEffect(() => {
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const r = await call(`/api/books?category=${encodeURIComponent(category)}&q=${encodeURIComponent(q)}`);
        if (!r.ok) throw new Error();
        setBooks(r.data); setMsg(null);
      } catch { flash("err", "Can't reach the library right now. Check that the gateway is running on port 8080."); }
      setLoading(false);
    }, 200);
    return () => clearTimeout(t);
  }, [category, q]);
  useEffect(() => { loadStock(); }, [loadStock]);
  useEffect(() => { loadLoans(); }, [loadLoans]);

  async function borrow(book) {
    if (!member) { flash("err", "Please join or sign in first."); return setTab("account"); }
    setBusy(true);
    const r = await call("/api/loans", { method: "POST", body: JSON.stringify({ email: member.email, bookId: book.id }) }).catch(() => null);
    setBusy(false);
    if (r?.ok) { flash("ok", `You borrowed "${book.title}". Due ${r.data.dueDate}. A confirmation email is on its way.`); loadStock(); loadLoans(); }
    else flash("err", r?.data?.error || "Something went wrong. Please try again.");
  }
  async function giveBack(loan, late = 0) {
    setBusy(true);
    const r = await call(`/api/loans/${loan.id}/return?demoDaysLate=${late}`, { method: "POST" }).catch(() => null);
    setBusy(false);
    if (r?.ok) { flash("ok", r.data.finePaise > 0 ? `Returned "${loan.title}". Late fine: ${rupees(r.data.finePaise)}.` : `Returned "${loan.title}". Thank you!`); loadStock(); loadLoans(); }
    else flash("err", r?.data?.error || "Could not return the book.");
  }

  const active = loans.filter((l) => l.status === "BORROWED");
  return (
    <>
      <header className="bar">
        <button className="logo" onClick={() => setTab("books")}>Library Hub</button>
        <nav>
          <button className={tab === "books" ? "on" : ""} onClick={() => setTab("books")}>Catalogue</button>
          <button className={tab === "loans" ? "on" : ""} onClick={() => setTab("loans")}>My loans{active.length ? ` (${active.length})` : ""}</button>
          <button className={tab === "account" ? "on" : ""} onClick={() => setTab("account")}>{member ? member.name.split(" ")[0] : "Join / sign in"}</button>
        </nav>
      </header>
      <main>
        {msg && <p className={`msg ${msg.kind}`} role={msg.kind === "err" ? "alert" : "status"}>{msg.text}</p>}

        {tab === "books" && (<>
          <section className="hero"><h1>Find your next read.</h1><p>Search the catalogue, then borrow for 14 days. You can hold up to 3 books at a time.</p></section>
          <input className="search" type="search" placeholder="Search by title or author" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search books" />
          <div className="chips" role="tablist" aria-label="Categories">
            {CATS.map((c) => <button key={c} className={c === category ? "on" : ""} onClick={() => setCategory(c)}>{c}</button>)}
          </div>
          {loading ? <p className="muted">Loading books…</p> : books.length === 0 ? <p className="muted">No books match your search.</p> : (
            <ul className="grid">
              {books.map((b) => {
                const c = copies[b.id]; const avail = c ? c.available : null;
                return (
                  <li key={b.id} className="card">
                    <div className={`cover c${b.id % 6}`} aria-hidden="true"><span>{b.title}</span></div>
                    <h2>{b.title}</h2>
                    <p className="author">{b.author} · {b.category}</p>
                    <p className="desc">{b.description}</p>
                    <div className="row">
                      <span className={avail === 0 ? "stock out" : "stock"}>{avail === null ? "" : avail === 0 ? "All copies out" : `${avail} of ${c.total} available`}</span>
                      <button disabled={busy || avail === 0} onClick={() => borrow(b)}>Borrow</button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </>)}

        {tab === "loans" && (
          <section className="narrow">
            <h1>My loans</h1>
            {!member ? <p className="muted">Sign in to see your loans. <button className="link" onClick={() => setTab("account")}>Go to sign in</button></p>
              : loans.length === 0 ? <p className="muted">You haven't borrowed anything yet.</p> : (
              <ul className="loans">
                {loans.map((l) => (
                  <li key={l.id}>
                    <div><b>{l.title}</b>
                      <div className="muted">{l.status === "BORROWED" ? `Due ${l.dueDate}` : `Returned${l.finePaise ? `, fine ${rupees(l.finePaise)}` : ""}`}</div></div>
                    {l.status === "BORROWED" && <div className="btns">
                      <button disabled={busy} onClick={() => giveBack(l)}>Return</button>
                      <button className="ghost" disabled={busy} onClick={() => giveBack(l, 5)} title="Demo: return as if 5 days late (fine ₹5 per day)">Return 5 days late</button></div>}
                  </li>
                ))}
              </ul>)}
          </section>
        )}

        {tab === "account" && <Account member={member} setMember={setMember} flash={flash} setTab={setTab} />}
      </main>
    </>
  );
}

function Account({ member, setMember, flash, setTab }) {
  const [mode, setMode] = useState("join");
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [busy, setBusy] = useState(false);
  const save = (m) => { setMember(m); try { localStorage.setItem("member", JSON.stringify(m)); } catch {} };
  async function submit(e) {
    e.preventDefault(); setBusy(true);
    const r = mode === "join"
      ? await call("/api/members", { method: "POST", body: JSON.stringify({ name, email }) }).catch(() => null)
      : await call(`/api/members?email=${encodeURIComponent(email)}`).catch(() => null);
    setBusy(false);
    if (r?.ok) { save({ name: r.data.name, email: r.data.email }); flash("ok", `Welcome, ${r.data.name}.`); setTab("books"); }
    else flash("err", r?.data?.error || "Can't reach the library right now.");
  }
  if (member) return (
    <section className="narrow"><h1>Your account</h1><p>{member.name}<br /><span className="muted">{member.email}</span></p>
      <button onClick={() => { setMember(null); try { localStorage.removeItem("member"); } catch {} }}>Sign out</button></section>);
  return (
    <section className="narrow">
      <h1>{mode === "join" ? "Join the library" : "Sign in"}</h1>
      <form onSubmit={submit}>
        {mode === "join" && <label>Full name<input required value={name} onChange={(e) => setName(e.target.value)} /></label>}
        <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></label>
        <button className="primary" disabled={busy}>{busy ? "Please wait…" : mode === "join" ? "Join" : "Sign in"}</button>
      </form>
      <p className="muted">{mode === "join" ? "Already a member?" : "New here?"} <button className="link" onClick={() => setMode(mode === "join" ? "signin" : "join")}>{mode === "join" ? "Sign in" : "Join"}</button></p>
      <p className="muted small">Demo sign-in uses email only. A real library would add a password or one-time code.</p>
    </section>);
}
