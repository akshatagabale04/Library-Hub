// The browser only ever talks to the API gateway.
export const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
